///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
// 
//	Aleksandr's Notes:
//  All code that I have aded for this assignment is mark with "ADDED/CHANGED" in the sections below.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// ====== ADDED/CHANGED: initialize texture counter ======
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	// ADDED/CHANGED: delete textures, not generate
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, 0);

		if (m_textureIDs[i].ID != 0)
			glDeleteTextures(1, &m_textureIDs[i].ID);

		m_textureIDs[i].ID = 0;
		m_textureIDs[i].tag.clear();
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

// ====== ADDED/CHANGED: Created light ======
/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Configures various material settings for the objects
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	OBJECT_MATERIAL counter;
	counter.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	counter.ambientStrength = 0.2f;
	counter.diffuseColor = glm::vec3(0.75f, 0.65f, 0.4f);
	counter.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	counter.shininess = 3.0f;
	counter.tag = "counter";
	m_objectMaterials.push_back(counter);

	OBJECT_MATERIAL wood;
	wood.ambientColor = glm::vec3(0.25f, 0.18f, 0.10f);
	wood.ambientStrength = 0.2f;
	wood.diffuseColor = glm::vec3(0.35f, 0.20f, 0.08f);
	wood.specularColor = glm::vec3(0.15f, 0.1f, 0.1f);
	wood.shininess = 2.0f;
	wood.tag = "wood";
	m_objectMaterials.push_back(wood);

	OBJECT_MATERIAL metal;
	metal.ambientColor = glm::vec3(0.25f, 0.25f, 0.27f);
	metal.ambientStrength = 0.28f;
	metal.diffuseColor = glm::vec3(0.35f, 0.35f, 0.36f);
	metal.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	metal.shininess = 74.0f;
	metal.tag = "metal";
	m_objectMaterials.push_back(metal);

	OBJECT_MATERIAL towel;
	towel.ambientColor = glm::vec3(0.9f, 0.9f, 0.9f);
	towel.ambientStrength = 0.25f;
	towel.diffuseColor = glm::vec3(0.97f, 0.97f, 0.97f);
	towel.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
	towel.shininess = 2.0f;
	towel.tag = "towel";
	m_objectMaterials.push_back(towel);

	OBJECT_MATERIAL cardboard;
	cardboard.ambientColor = glm::vec3(0.45f, 0.35f, 0.20f);
	cardboard.ambientStrength = 0.25f;
	cardboard.diffuseColor = glm::vec3(0.7f, 0.55f, 0.3f);
	cardboard.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	cardboard.shininess = 1.5f;
	cardboard.tag = "cardboard";
	m_objectMaterials.push_back(cardboard);

	OBJECT_MATERIAL ceramic;
	ceramic.ambientColor = glm::vec3(0.92f, 0.92f, 0.92f);
	ceramic.ambientStrength = 0.28f;
	ceramic.diffuseColor = glm::vec3(0.95f, 0.95f, 0.95f);
	ceramic.specularColor = glm::vec3(0.25f, 0.25f, 0.25f);
	ceramic.shininess = 28.0f;
	ceramic.tag = "ceramic";
	m_objectMaterials.push_back(ceramic);

	OBJECT_MATERIAL plastic;
	plastic.ambientColor = glm::vec3(0.12f, 0.12f, 0.12f);
	plastic.ambientStrength = 0.22f;
	plastic.diffuseColor = glm::vec3(0.20f, 0.20f, 0.20f);
	plastic.specularColor = glm::vec3(0.15f, 0.15f, 0.15f);
	plastic.shininess = 4.0f;
	plastic.tag = "plastic";
	m_objectMaterials.push_back(plastic);

}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Adds and configures light sources for the 3D scene.
 *  This includes one directional light and one point light.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Turn on custom lighting
	m_pShaderManager->setBoolValue("bUseLighting", true);

	// === Main Directional Light (window sunlight from right) ===
	m_pShaderManager->setVec3Value("directionalLight.direction", -0.6f, -0.45f, -0.3f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.22f, 0.20f, 0.18f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.78f, 0.70f, 0.60f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 1.0f, 0.95f, 0.85f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// === Fill Light ===
	m_pShaderManager->setVec3Value("pointLights[0].position", -1.0f, 1.5f, -1.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.35f, 0.35f, 0.45f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.8f, 0.8f, 0.9f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

}



/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	CreateGLTexture("../../Utilities/textures/wood.jpg", "wood");   // Tray
	CreateGLTexture("../../Utilities/textures/counter.jpg", "counter");  // Counter-top
	CreateGLTexture("../../Utilities/textures/metal.jpg", "metal");  // Saucepan
	CreateGLTexture("../../Utilities/textures/paper towel.jpg", "paper towel"); // Paper towel
	CreateGLTexture("../../Utilities/textures/cardboard.jpg", "cardboard"); // Paper towel
	CreateGLTexture("../../Utilities/textures/jar_blue.png", "jar_blue"); // Coffee box
	CreateGLTexture("../../Utilities/textures/jar_green.png", "jar_green"); // Coffee box
	CreateGLTexture("../../Utilities/textures/coffee_mug.jpg", "coffee_mug"); // Mug
	CreateGLTexture("../../Utilities/textures/mug_handle.jpg", "mug_handle"); // Mug

	BindGLTextures();

	// Phong lighting
	DefineObjectMaterials();
	SetupSceneLights();


	// Meshes
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();

}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

// ====== ADDED/CHANGED: Created the scene: ======

/****************************************************************/
/***                     Countertop (base)                    ***/
/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.0f, 0.5f, 3.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, -0.25f, -1.50f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Countertop texture
	SetTextureUVScale(0.6f, 0.6f);
	SetShaderTexture("counter");

	SetShaderMaterial("counter");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

/****************************************************************/
/***					Countertop END						  ***/
/****************************************************************/


/****************************************************************/
/*                        Wooden Tray						    */
/*  Flattened bottom box, 4 leaned side boxes, 4 prisms,        */
/*  and 2 embedded torus handles (half-torus look).             */
/****************************************************************/


	/****************************************************************/
	/***                       Bottom slab                        ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.19f, 0.05f, 1.98f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.025f, -2.20f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.50f, 0.30f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/


	/****************************************************************/
	/***                   Left wall  (-X side)                   ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 0.18f, 1.98f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 10.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.58f, 0.13f, -2.20f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.45f, 0.18f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/


	/****************************************************************/
	/***                   Right wall  (+X side)                  ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 0.18f, 1.98f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -10.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.58f, 0.13f, -2.20f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.45f, 0.18f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/


	/****************************************************************/
	/***                   Back wall  (-Z side)                   ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.18f, 0.18f, 0.05f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -10.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.13f, -3.18f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.70f, 0.18f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/


	/****************************************************************/
	/***                   Front wall  (+Z side)                  ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.18f, 0.18f, 0.05f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 10.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.13f, -1.22f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.70f, 0.18f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/


	/****************************************************************/
	/***               Corner prism: NW  (-X, -Z)                 ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.03f, 0.16f, 0.03f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -10.0f;
	YrotationDegrees = 45.0f;
	ZrotationDegrees = 10.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.58f, 0.13f, -3.18f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.35f, 0.35f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();
	/****************************************************************/


	/****************************************************************/
	/***               Corner prism: NE  (+X, -Z)                 ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.03f, 0.16f, 0.03f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -10.0f;
	YrotationDegrees = -45.0f;
	ZrotationDegrees = -10.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.58f, 0.13f, -3.18f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.35f, 0.35f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();
	/****************************************************************/


	/****************************************************************/
	/***               Corner prism: SW  (-X, +Z)                 ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.03f, 0.16f, 0.03f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 10.0f;
	YrotationDegrees = 135.0f;
	ZrotationDegrees = -10.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.58f, 0.13f, -1.22f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.35f, 0.35f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();
	/****************************************************************/


	/****************************************************************/
	/***               Corner prism: SE  (+X, +Z)                 ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.03f, 0.16f, 0.03f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 10.0f;
	YrotationDegrees = 225.0f;
	ZrotationDegrees = 10.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.58f, 0.13f, -1.22f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.35f, 0.35f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();
	/****************************************************************/


	/****************************************************************/
	/***             Left handle (embedded torus)  [-X]           ***/
	/****************************************************************/
	m_basicMeshes->LoadTorusMesh(0.03f);

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.20f, 0.40f, 0.90f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = -82.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.58f, 0.138f, -2.20f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.50f, 0.50f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/


	/****************************************************************/
	/***             Right handle (embedded torus)  [+X]          ***/
	/****************************************************************/
	m_basicMeshes->LoadTorusMesh(0.03f);

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.20f, 0.40f, 0.90f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 82.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.58f, 0.138f, -2.20f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.50f, 0.50f);
	SetShaderTexture("wood");

	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/

/****************************************************************/
/***					TRAY END							  ***/
/****************************************************************/


/****************************************************************/
/***                        SAUCEPAN                          ***/
/****************************************************************/

	// convenient const to move the saucepan
	const float panX = 0.85f;
	const float panY = 0.22f;
	const float panZ = -2.5f;

	/****************************************************************/
	/***                Bottom bulge						      ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.452f, 0.05f, 0.452);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(panX, panY - 0.13f, panZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(1.2f, 1.2f);
	SetShaderTexture("metal");

	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/****************************************************************/
	/***                     Side wall			                  ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.45f, 0.3f, 0.45f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(panX, panY - 0.13f, panZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("metal");

	SetShaderMaterial("metal");


	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh(false, false, true);

	/****************************************************************/


	/****************************************************************/
	/***                     Top rim				              ***/
	/****************************************************************/

	m_basicMeshes->LoadTorusMesh(0.025f);

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.45f, 0.45f, 0.1f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(panX, panY + 0.17f, panZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("metal");

	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/

	/****************************************************************/
	/***                   Handle						          ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.025f, 0.6f, 0.045f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -10.0f;
	YrotationDegrees = 42.0f;
	ZrotationDegrees = -91.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(panX - 0.8f, panY + 0.18f, panZ + 0.7f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.8f, 0.8f);
	SetShaderTexture("metal");

	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/****************************************************************/
	/***					 Bracket							  ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.2f, 0.06f, 0.18f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -10.0f;
	YrotationDegrees = -50.0f;   // match handle yaw
	ZrotationDegrees = -5.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(panX - 0.4f, panY + 0.11f, panZ + 0.35f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(0.9f, 0.9f);
	SetShaderTexture("metal");

	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();
	/****************************************************************/

	/****************************************************************/
	/***						 Rivets							  ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.02f, 0.02f, 0.02f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the right mesh
	positionXYZ = glm::vec3(panX - 0.345f, panY + 0.11f, panZ + 0.375f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("metal");

	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ position for the left mesh
	positionXYZ = glm::vec3(panX - 0.42f, panY + 0.11f, panZ + 0.3f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("metal");

	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
/****************************************************************/
/***                      SAUCEPAN END                        ***/
/****************************************************************/

/****************************************************************/
/***                        PAPER TOWEL                       ***/
/****************************************************************/

	// convenient const to move the whole paper towel
	const float towelX = -0.10f;
	const float towelY = -0.95f;
	const float towelZ = -2.85f;

	/****************************************************************/
	/***                    Paper Roll (cylinder)                 ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.37f, 1.0f, 0.37f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.10f, 0.055f, -2.85f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(1.2f, 1.0f);
	SetShaderTexture("paper towel");  
	
	SetShaderMaterial("towel");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/


	/****************************************************************/
	/***        Recessed Inner Hole (short cylinder, top)         ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.16f, 0.02f, 0.16f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.10f, 1.0528f, -2.85f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetShaderColor(0.63f, 0.52f, 0.34f, 1.0f);
	SetShaderTexture("cardboard");

	SetShaderMaterial("cardboard");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/


	/****************************************************************/
	/***        Hole Top Cap								      ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.15f, 0.019f, 0.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.10f, 1.0572f, -2.85f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Color (dark so it reads hollow)
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/


/****************************************************************/
/***			   Partial Hanging Sheet					  ***/
/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.3404f, 1.0f, 0.002f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 230.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.2860f, 0.55f, -2.6);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetShaderColor(0.92f, 0.92f, 0.90f, 1.0f);
	SetTextureUVScale(0.4f, 1.0f);
	SetShaderTexture("paper towel");

	SetShaderMaterial("towel");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

/****************************************************************/
/***                  Paper Towel end			              ***/
/****************************************************************/


/****************************************************************/
/***                       COFFEE JARS                        ***/
/****************************************************************/

/****************************************************************/
/***                 Left Jar � Body			              ***/
/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.32f, 0.46f, 0.26f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 25.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.30f, 0.25f, -2.62f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("jar_blue");

	SetShaderMaterial("plastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/


	/****************************************************************/
	/***                    Left Jar � Lid (black)                ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.32f, 0.08f, 0.26f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 25.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.30f, 0.52f, -2.62f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Color
	SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f);

	SetShaderMaterial("plastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/


	/****************************************************************/
	/***            Right Jar  � Body						      ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.32f, 0.46f, 0.24f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.90f, 0.25f, -2.70f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("jar_green");

	SetShaderMaterial("plastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/


	/****************************************************************/
	/***                   Right Jar � Lid (green)                ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.32f, 0.08f, 0.24f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.90f, 0.52f, -2.70f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Color
	SetShaderColor(0.02f, 0.40f, 0.22f, 1.0f);

	SetShaderMaterial("plastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
/****************************************************************/
/***                     COFFEE JARS END                      ***/
/****************************************************************/


/****************************************************************/
/***                          BIG MUG                         ***/
/****************************************************************/

	// convenient const to move the whole mug
	const float mugX = -0.45f;
	const float mugY = 0.22f;
	const float mugZ = -1.90f;

	/****************************************************************/
	/***                  Bottom bulge (sphere)                   ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.4f, 0.05f, 0.4f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(mugX, mugY - 0.085f, mugZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("coffee_mug");

	SetShaderMaterial("ceramic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/


	/****************************************************************/
	/***                  Outer side wall (open)                  ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.4f, 0.27f, 0.4f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(mugX, mugY - 0.08, mugZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("coffee_mug");

	SetShaderMaterial("ceramic");

	// draw the mesh with transformation values (sides only)
	m_basicMeshes->DrawCylinderMesh(false, false, true);
	/****************************************************************/


	/****************************************************************/
	/***                   Inner hollow		                      ***/
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.39f, 0.27f, 0.39f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(mugX, mugY - 0.08, mugZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("coffee_mug");

	SetShaderMaterial("ceramic");

	// draw the mesh with transformation values (sides only)
	m_basicMeshes->DrawCylinderMesh(false, false, true);
	/****************************************************************/


	/****************************************************************/
	/***                         Rim (torus)                      ***/
	/****************************************************************/
	m_basicMeshes->LoadTorusMesh(0.025f);

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.4f, 0.4f, 0.1f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(mugX, mugY + 0.19, mugZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("coffee_mug");

	SetShaderMaterial("ceramic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/


	/****************************************************************/
	/***                        Handle (torus)                    ***/
	/****************************************************************/
	m_basicMeshes->LoadTorusMesh(0.1f);

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.08f, 0.135f, 0.4f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -33.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(mugX + 0.36f, mugY + 0.05f, mugZ + 0.26);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// textures
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("mug_handle");

	SetShaderMaterial("ceramic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
/****************************************************************/
/***                        BIG MUG END                       ***/
/****************************************************************/


/****************************************************************/
/***                    WHITE BACKGROUND                      ***/
/****************************************************************/

// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(10.0f, 10.0f, 0.05f); 

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 2.0f, -3.2f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Textures and color
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderMaterial("towel");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	/***                    WHITE BACKGROUND END                  ***/
	/****************************************************************/
}